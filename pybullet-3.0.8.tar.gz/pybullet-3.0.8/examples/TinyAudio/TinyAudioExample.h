
#ifndef TINY_AUDIO_EXAMPLE_H
#define TINY_AUDIO_EXAMPLE_H

class CommonExampleInterface* TinyAudioExampleCreateFunc(struct CommonExampleOptions& options);

#endif  //TINY_AUDIO_EXAMPLE_H