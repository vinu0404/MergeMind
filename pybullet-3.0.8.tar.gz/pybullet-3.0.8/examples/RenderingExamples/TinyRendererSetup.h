#ifndef TINYRENDERER_SETUP_H
#define TINYRENDERER_SETUP_H

class CommonExampleInterface* TinyRendererCreateFunc(struct CommonExampleOptions& options);

#endif  //TINYRENDERER_SETUP_H
