#ifndef GRAPHICS_SERVER_EXAMPLE_H
#define GRAPHICS_SERVER_EXAMPLE_H

class CommonExampleInterface* GraphicsServerCreateFuncBullet(struct CommonExampleOptions& options);

#endif  //GRAPHICS_SERVER_EXAMPLE_H
