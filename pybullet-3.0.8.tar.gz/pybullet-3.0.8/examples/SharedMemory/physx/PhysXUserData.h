#ifndef PHYSX_USER_DATA_H
#define PHYSX_USER_DATA_H

struct MyPhysXUserData
{
	int m_graphicsUniqueId;
	int m_bodyUniqueId;
	int m_linkIndex;
};
#endif //PHYSX_USER_DATA_H