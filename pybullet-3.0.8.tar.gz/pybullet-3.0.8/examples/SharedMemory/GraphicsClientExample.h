#ifndef GRAPHICS_CLIENT_EXAMPLE_H
#define GRAPHICS_CLIENT_EXAMPLE_H


class CommonExampleInterface* GraphicsClientCreateFunc(struct CommonExampleOptions& options);

#endif  //GRAPHICS_CLIENT_EXAMPLE_H
